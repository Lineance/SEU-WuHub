import type {
  CategoriesResponse,
  ArticlesResponse,
  ArticleDetailResponse,
  ApiError,
} from './types'

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000'

const USE_MOCK = true

async function fetchAPI<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`
  
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
    })

    if (!response.ok) {
      const error: ApiError = await response.json().catch(() => ({
        message: '请求失败',
      }))
      throw new Error(error.message || `HTTP ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    if (error instanceof Error) {
      throw error
    }
    throw new Error('未知错误')
  }
}

export const api = {
  getCategories: async (): Promise<CategoriesResponse> => {
    if (USE_MOCK) {
      return {
        data: [
          {
            id: '1',
            name: '通知公告',
            icon: 'bell',
            children: [
              {
                id: '1-1',
                name: '教务处通知',
                icon: 'file-text',
              },
              {
                id: '1-2',
                name: '学生工作处通知',
                icon: 'file-text',
              },
              {
                id: '1-3',
                name: '国际交流处通知（长期项目 / 短期访学）',
                icon: 'globe',
              },
            ],
          },
          {
            id: '2',
            name: '奖学金与荣誉评定',
            icon: 'trophy',
            children: [
              {
                id: '2-1',
                name: '国家奖学金',
                icon: 'trophy',
              },
              {
                id: '2-2',
                name: '校级奖学金',
                icon: 'trophy',
              },
              {
                id: '2-3',
                name: '荣誉称号评定',
                icon: 'trophy',
              },
            ],
          },
          {
            id: '3',
            name: '教学运行与课程安排',
            icon: 'book',
            children: [
              {
                id: '3-1',
                name: '课程表查询',
                icon: 'book',
              },
              {
                id: '3-2',
                name: '选课系统入口',
                icon: 'book',
              },
              {
                id: '3-3',
                name: '考试安排通知',
                icon: 'book',
              },
            ],
          },
          {
            id: '4',
            name: '新生指南与常见问题',
            icon: 'help-circle',
            children: [
              {
                id: '4-1',
                name: '入学须知',
                icon: 'help-circle',
              },
              {
                id: '4-2',
                name: '校园地图导航',
                icon: 'compass',
              },
              {
                id: '4-3',
                name: '常见问题 FAQ',
                icon: 'help-circle',
              },
            ],
          },
          {
            id: '5',
            name: '选课、补退选与成绩相关说明',
            icon: 'file-text',
            children: [
              {
                id: '5-1',
                name: '选课指南',
                icon: 'file-text',
              },
              {
                id: '5-2',
                name: '补退选流程',
                icon: 'file-text',
              },
              {
                id: '5-3',
                name: '成绩查询与申诉',
                icon: 'file-text',
              },
            ],
          },
          {
            id: '6',
            name: '宿舍 / 校园卡 / 网络服务',
            icon: 'home',
            children: [
              {
                id: '6-1',
                name: '宿舍管理系统',
                icon: 'home',
              },
              {
                id: '6-2',
                name: '校园卡充值与挂失',
                icon: 'home',
              },
              {
                id: '6-3',
                name: '网络服务报修',
                icon: 'home',
              },
            ],
          },
          {
            id: '7',
            name: '学术科研与竞赛',
            icon: 'graduation-cap',
            children: [
              {
                id: '7-1',
                name: '科研训练（SRTP / 国创 / 校创）',
                icon: 'graduation-cap',
                children: [
                  {
                    id: '7-1-1',
                    name: 'SRTP 项目申报',
                    icon: 'graduation-cap',
                  },
                  {
                    id: '7-1-2',
                    name: '国家级大学生创新创业训练计划',
                    icon: 'graduation-cap',
                  },
                  {
                    id: '7-1-3',
                    name: '校级创新项目',
                    icon: 'graduation-cap',
                  },
                ],
              },
              {
                id: '7-2',
                name: '学科竞赛与创新创业项目申报',
                icon: 'graduation-cap',
              },
              {
                id: '7-3',
                name: 'iGEM / 数模 / 挑战杯 / 互联网+',
                icon: 'graduation-cap',
              },
            ],
          },
          {
            id: '8',
            name: '行政服务与表格下载',
            icon: 'building',
            children: [
              {
                id: '8-1',
                name: '证明材料办理',
                icon: 'building',
              },
              {
                id: '8-2',
                name: '表格下载中心',
                icon: 'building',
              },
              {
                id: '8-3',
                name: '跨校交流、联合培养与学籍异动相关申请材料',
                icon: 'building',
              },
            ],
          },
          {
            id: '9',
            name: 'AI & Digital Resources',
            icon: 'lightbulb',
            children: [
              {
                id: '9-1',
                name: 'Campus Tools',
                icon: 'lightbulb',
              },
              {
                id: '9-2',
                name: 'API / Developer Notes',
                icon: 'lightbulb',
              },
            ],
          },
        ],
      }
    }
    return fetchAPI<CategoriesResponse>('/api/v1/categories')
  },

  getArticles: async (params?: {
    category_id?: string
    page?: number
    page_size?: number
  }): Promise<ArticlesResponse> => {
    const searchParams = new URLSearchParams()
    if (params?.category_id) searchParams.append('category_id', params.category_id)
    if (params?.page) searchParams.append('page', params.page.toString())
    if (params?.page_size) searchParams.append('page_size', params.page_size.toString())
    
    const queryString = searchParams.toString()
    const endpoint = `/api/v1/articles${queryString ? `?${queryString}` : ''}`
    
    return fetchAPI<ArticlesResponse>(endpoint)
  },

  getArticleDetail: async (id: string | number): Promise<ArticleDetailResponse> => {
    if (USE_MOCK) {
      return {
        data: {
          id: Number(id),
          title: '测试文章详情（Mock）',
          summary: '这是一条测试文章的摘要，用于测试文章详情页的 UI 显示。',
          content_md: `
# 奖学金通知

这是一个用于测试的文章内容，用于测试 Markdown 渲染效果。

## 测试内容

- 列表项 1
- 列表项 2
- 列表项 3

## 图片测试

![测试图片](https://via.placeholder.com/150)

## 链接测试

这是一个[测试链接](https://example.com)。

## 无序列表

- 项目 1
- 项目 2
- 项目 3

`,
          source: '教务处',
          published_at: '2025-01-01',
          updated_at: '2025-01-01',
          source_url: 'https://example.com',
          tags: ['通知', '测试'],
          category_id: '1',
          attachments: [
            {
              name: '奖学金申请表.docx',
              url: 'https://example.com/scholarship.docx',
              type: 'docx',
            },
            {
              name: '培养方案.pdf',
              url: 'https://example.com/plan.pdf',
              type: 'pdf',
            },
            {
              name: '附件说明.xlsx',
              url: 'https://example.com/attachment.xlsx',
              type: 'xlsx',
            },
          ],
        },
      }
    }
    return fetchAPI<ArticleDetailResponse>(`/api/v1/articles/${id}`)
  },

  searchArticles: async (params?: {
    q?: string
    page?: number
    page_size?: number
  }): Promise<ArticlesResponse> => {
    if (USE_MOCK) {
      const q = params?.q || ''
      const today = new Date().toISOString().split('T')[0]
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0]
      const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().split('T')[0]
      const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0]
      
      return {
        data: [
          {
            id: 1,
            title: `关于${q}的通知（测试数据）`,
            summary: '这是一条测试数据，用于本地测试搜索功能。',
            source: '教务处',
            published_at: today,
            tags: ['通知', '测试'],
            category_id: '1',
          },
          {
            id: 2,
            title: `${q}相关说明（测试数据）`,
            summary: '这是另一条测试数据，用于本地测试搜索功能。',
            source: '学院办公室',
            published_at: yesterday,
            tags: ['说明', '测试'],
            category_id: '2',
          },
          {
            id: 3,
            title: `${q}奖学金评定通知（测试数据）`,
            summary: '这是第三条测试数据，用于本地测试搜索功能。',
            source: '本科生院',
            published_at: weekAgo,
            tags: ['奖学金', '通知'],
            category_id: '3',
          },
          {
            id: 4,
            title: `${q}课程安排说明（测试数据）`,
            summary: '这是第四条测试数据，用于本地测试搜索功能。',
            source: '教务处',
            published_at: monthAgo,
            tags: ['课程', '说明'],
            category_id: '4',
          },
          {
            id: 5,
            title: `${q}科研训练项目通知（测试数据）`,
            summary: '这是第五条测试数据，用于本地测试搜索功能。',
            source: '学院办公室',
            published_at: today,
            tags: ['科研', '通知'],
            category_id: '5',
          },
          {
            id: 6,
            title: `${q}竞赛报名通知（测试数据）`,
            summary: '这是第六条测试数据，用于本地测试搜索功能。',
            source: '本科生院',
            published_at: yesterday,
            tags: ['竞赛', '通知'],
            category_id: '6',
          },
        ],
        pagination: {
          page: 1,
          page_size: 20,
          total: 2,
          total_pages: 1,
        },
      }
    }

    const searchParams = new URLSearchParams()
    if (params?.q) searchParams.append('q', params.q)
    if (params?.page) searchParams.append('page', params.page.toString())
    if (params?.page_size) searchParams.append('page_size', params.page_size.toString())
    
    const queryString = searchParams.toString()
    const endpoint = `/api/v1/search${queryString ? `?${queryString}` : ''}`
    
    return fetchAPI<ArticlesResponse>(endpoint)
  },
}
