const FAVORITES_KEY = 'wuhub_favorites'

export type FavoriteArticle = {
  id: string
  title: string
  source?: string
  published_at?: string
}

export function getFavorites(): FavoriteArticle[] {
  if (typeof window === 'undefined') {
    return []
  }

  try {
    const stored = localStorage.getItem(FAVORITES_KEY)
    return stored ? JSON.parse(stored) : []
  } catch {
    return []
  }
}

export function addFavorite(article: FavoriteArticle): void {
  const favorites = getFavorites()
  if (!favorites.some(fav => fav.id === article.id)) {
    favorites.push(article)
    setFavorites(favorites)
  }
}

export function removeFavorite(articleId: string): void {
  const favorites = getFavorites()
  const filtered = favorites.filter(fav => fav.id !== articleId)
  setFavorites(filtered)
}

export function isFavorite(articleId: string): boolean {
  const favorites = getFavorites()
  return favorites.some(fav => fav.id === articleId)
}

export function toggleFavorite(article: FavoriteArticle): void {
  if (isFavorite(article.id)) {
    removeFavorite(article.id)
  } else {
    addFavorite(article)
  }
}

function setFavorites(favorites: FavoriteArticle[]): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites))
  }
}
