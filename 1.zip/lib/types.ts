export interface Category {
  id: string
  name: string
  icon?: string
  parent_id?: string | null
  children?: Category[]
}

export interface Resource {
  id: string
  type: 'image' | 'document' | 'media' | 'other'
  url: string
  filename?: string
  size?: number
}

export interface Article {
  id: number
  title: string
  summary: string
  source: string
  published_at: string
  tags: string[]
  category_id: string
}

export interface Attachment {
  name: string
  url: string
  type?: string
}

export interface ArticleDetail extends Article {
  content_md?: string
  content?: string
  source_url: string
  updated_at: string
  resources?: Resource[]
  attachments?: Attachment[]
}

export interface PaginationMeta {
  page: number
  page_size: number
  total: number
  total_pages: number
}

export interface ArticlesResponse {
  data: Article[]
  pagination: PaginationMeta
}

export interface CategoriesResponse {
  data: Category[]
}

export interface ArticleDetailResponse {
  data: ArticleDetail
}

export interface ApiError {
  message: string
  code?: string
}
